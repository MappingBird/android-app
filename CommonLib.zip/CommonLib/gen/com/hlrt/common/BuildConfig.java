/** Automatically generated file. DO NOT MODIFY */
package com.hlrt.common;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}